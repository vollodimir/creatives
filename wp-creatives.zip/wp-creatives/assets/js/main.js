//--plavna prokrutka
const smoothLinks = document.querySelectorAll('a[href^="#"]');
for (let smoothLink of smoothLinks) {
  smoothLink.addEventListener('click', function (e) {
    e.preventDefault();
    const id = smoothLink.getAttribute('href');

    if (id !== '#') {
      document.querySelector(id).scrollIntoView({
        behavior: 'smooth',
        block: 'start',
      });
		

    }
  });
}

//--hiden-btn
const goTop = document.querySelector('.go-top');
window.onscroll = () => {
  if (window.pageYOffset < 800) {
    goTop.style.display = 'none';
  } else {
    goTop.style.display = 'block';
  }
};

//--hiden-btn--end-
//
jQuery(document).ready(function ($) {
			/////---Form validation----////////
// 			$('.contact__btn').attr("disabled", true);
// 			$("*.wpcf7-form-control").change(() => {
// 					const all = $('.wpcf7-form-control').map(function() {
//       	  return ($(this).val() || false);
//        	}).get();
// 				if (jQuery.inArray(false, all) !== -1) {
// 					$('.contact__btn').attr("disabled", true);
// 				} else {
// 					$('.contact__btn').attr("disabled", false);
// 				}
// 			})
			//////----Form validation----///////

			
			
// 		  $('#all-menu').click(function () {
// 			$('.header__input').prop('checked', false);
// 		  });
			/////////////			
		});
