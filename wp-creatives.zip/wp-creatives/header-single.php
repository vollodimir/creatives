<!DOCTYPE html>
<html lang="<?php bloginfo('language'); ?>">
  <head>
    <meta charset="<?php bloginfo('charset'); ?>" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0" />
    <title><?php the_title(); ?>. <?php bloginfo('name'); ?></title>
    <meta name="description" content="<?php bloginfo('description'); ?>">

    <?php wp_head(); ?>
  </head>
  <body>
    <div class="wrapper">
      <header class="header" id="top">
        

          <!--fixed menu-->
          <div class="header__wrapper">
            <div class="header__container">
              <div class="header__navigation">
                <div class="header__logo logo">  
					        <?php 
                    if( get_custom_logo() ) {
                      the_custom_logo();
                    } else {
                      ?><a href="/"> <img src="<?php bloginfo('template_url'); ?>/assets/img/icon/logo.svg" alt=""> </a><?php
                    }
                  ?>
                </div>
                <input class="header__input" type="checkbox" />
                <div class="header__lines"></div>

                <div class="header__all-menu" id="all-menu">
                  <nav>
                    <?php wp_nav_menu(['menu_class' => 'header__menu']); ?>
                  </nav>
                  <div class="header__socials">
                    <a href="<?php echo get_option('facebook_url') ?>">
                      <i class="fa fa-facebook" aria-hidden="true"></i>
                    </a>
                    <a href="<?php echo get_option('twitter_url') ?>">
                      <i class="fa fa-twitter" aria-hidden="true"></i>
                    </a>
                    <a href="<?php echo get_option('skype_url') ?>">
                      <i class="fa fa-skype" aria-hidden="true"></i>
                    </a>
                    <a href="<?php echo get_option('linkedin_url') ?>">
                      <i class="fa fa-linkedin" aria-hidden="true"></i>
                    </a>
                  </div>
                </div>
              </div>
            </div>
         
          <!--fixed menu END-->
          
        </div>
      </header>