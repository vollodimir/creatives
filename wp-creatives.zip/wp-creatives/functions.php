<?php

	add_action( 'wp_enqueue_scripts', function () {

		wp_enqueue_style( 'normalize', get_template_directory_uri() . '/assets/css/normalize.css' );
		wp_enqueue_style( 'fontawesome', get_template_directory_uri() . '/assets/css/fontawesome.css' );
		wp_enqueue_style( 'style', get_template_directory_uri() . '/assets/css/style.css' );
		wp_enqueue_script( 'main', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), false, true );
		
	});

///////Theme options menu page////////
add_action( 'admin_menu', 'true_top_menu_page', 25 );
 	function true_top_menu_page(){
	
		add_menu_page(
			'WP Creatives Options', // тайтл страницы
			'WP Creatives', // текст ссылки в меню
			'manage_options', // права пользователя, необходимые для доступа к странице
			'wp_creatives', // ярлык страницы
			'wp_creatives_page_fn', // функция, которая выводит содержимое страницы
			'dashicons-admin-generic', // иконка, в данном случае из Dashicons
			63 // позиция в меню
		);

		add_submenu_page( 
			'wp_creatives', //$parent_slug, 
			'Socials links',//$page_title, 
			'Socials', // $menu_title, 
			'manage_options', //$capability, 
			'wp_creatives_socials', //$menu_slug, 
			'wp_creatives_subpage_fn', //$function, 
			3 //$position 
		);
	}
 




//////////////////////22222

function display_twitter_element(){
	?>
    	<input type="text" name="twitter_url" id="twitter_url" value="<?php echo get_option('twitter_url'); ?>" />
    <?php
}

function display_facebook_element(){
	?>
    	<input type="text" name="facebook_url" id="facebook_url" value="<?php echo get_option('facebook_url'); ?>" />
    <?php
}

function display_skype_element () {
	?>
    	<input type="text" name="skype_url" id="skype_url" value="<?php echo get_option('skype_url'); ?>" />
    <?php
}

function display_linkedin_element () {
	?>
    	<input type="text" name="linkedin_url" id="linkedin_url" value="<?php echo get_option('linkedin_url'); ?>" />
    <?php
}



function display_theme_panel_fields(){
	add_settings_section("section", "", null, "wp_creatives_socials");
    add_settings_field("facebook_url", "Facebook:", "display_facebook_element", "wp_creatives_socials", "section");
	add_settings_field("twitter_url", "Twitter:", "display_twitter_element", "wp_creatives_socials", "section");
    add_settings_field("skype_url", "Skype:", "display_skype_element", "wp_creatives_socials", "section");
    add_settings_field("linkedin_url", "Linkedin:", "display_linkedin_element", "wp_creatives_socials", "section");

    register_setting("section", "twitter_url");
    register_setting("section", "facebook_url");
    register_setting("section", "skype_url");
    register_setting("section", "linkedin_url");
}

add_action("admin_init", "display_theme_panel_fields");

///////Theme options menu page colback////////
function wp_creatives_page_fn(){

?>
<div class="wrap">
	<h1 class="title">WP Creatives Theme Guide</h1>
	<div class="card">
		<h2>Steps:</h2>
		<ol>
			<li>Download the <strong>Advanced Custom Fields</strong> and <strong>Contact Form 7</strong> plugins</li>
			<li>Download the demo data in site: <strong>Import</strong> &gt;&gt; <strong>Wordpress</strong> &gt;&gt; select the <strong>demo_data_wp_creatives.xml</strong> file</li>
			<li>Enjoy!</li>
		</ol>
	</div>
		<p>Plugins that will be needed: Advanced Custom Fields, Contact Form 7</p>
	
		<p>The demo data is located in the theme directory called <b>demo_data_wp_creatives.xml</b></p>

		<p>You can download demo data to the site using the following link: <b><a href="/wp-admin/import.php">Import</a> >> WordPress</b></p>
	
		<p><b>Theme site:</b> <a target="_blank" href="http://wp.pl.vn.ua/">wp.pl.vn.ua</a></p>
</div>
<?php
}


///////Save notise////////
add_action( 'admin_notices', 'true_custom_notice' );
function true_custom_notice() {
	if(
		isset( $_GET[ 'page' ] )
		&& isset( $_GET[ 'settings-updated' ] )
		&& true == $_GET[ 'settings-updated' ]
		) {
			echo '<div class="notice notice-success is-dismissible"><p>Settings updated!</p></div>';
	}
}


///////Theme options menu subpage colback////////
function wp_creatives_subpage_fn(){
	echo '<h1 class="wp-heading-inline">' . get_admin_page_title() . '</h1>';
	?>
	    <form method="post" action="options.php">
	        <?php 
	            settings_fields("section");
	            do_settings_sections("wp_creatives_socials");      
	            submit_button(); 
	        ?>          
	    </form>
	<?php
}













////////////Theme Supports///////////////
	add_theme_support( 'menus' );
	add_theme_support('post-thumbnails');
	add_theme_support('title-tag');
	add_theme_support('custom-logo');

?>


