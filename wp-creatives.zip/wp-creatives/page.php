<?php get_header('single'); ?>
<?php the_post(); ?>

<main>
        <section class="advantages" id="features">
          <div class="container">
            <div class="advantages__body">
              <div class="advantages__title">
                <div class="advantages__bg-letter">W</div>
                <p><?php the_title(); ?></p>
              </div>
              <div class="advantages__features" style="text-align:left;">
              <?php the_content(); ?>

              </div>
            </div>
          </div>
        </section>
    </main>




<?php get_footer(); ?>