<?php
/*
Template Name: Home Template
*/
?>

<?php get_header(); ?>
      <main>
        <section class="advantages" id="features">
          <div class="container">
            <div class="advantages__body">
              <div class="advantages__title">
                <div class="advantages__bg-letter"><?php 
                  if(function_exists('get_field')){
                    the_field('advantages_bg_letter'); 
                   } else {
                     echo 'W'; 
                  }
                ?></div>
                <p><?php 
                  if(function_exists('get_field')){
                    the_field('advantages_title'); 
                 } else {
                    echo 'WE ARE AN AWESOME AGENCy'; 
                }
                ?></p>
              </div>
              <div class="advantages__features">
                <?php
                  global $post;
                  $myposts = get_posts([ 
                    'numberposts' => -1,
                    // 'category'    => 3
                  ]);

                  if( $myposts ){
                    foreach( $myposts as $post ){
                      setup_postdata( $post );
                ?>

                <div class="feature"> 
                  <div class="feature__body">
                    <div class="feature__image">
                      <img src="<?php 
                        if(get_the_post_thumbnail_url()){
                           the_post_thumbnail_url();
                          } else {
                            echo bloginfo('template_url') . '/assets/img/icon/feature_startup.svg'; 
                        }
                      ?>" alt="<?php the_title(); ?>" />
                    </div>
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <p>
                    <?php the_content(); ?>
                    </p>
                  </div>
                </div><!-- <?php the_ID(); ?> END -->
                
                <?php 
                    }
                  } else {
                ?>      
                       <div style="font-size:40px; margin: 0 auto;">
                        Posts not found!
                       </div>
                <?php 
                    }
                    wp_reset_postdata(); 
                ?>
              </div>
            </div>
          </div>
        </section>
        <!-- advantages END -->
        <section
          id="contact-us"
          class="contact"
          style="
            background-image: linear-gradient(0deg, rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.8)),
              url('<?php
 						if( function_exists('get_field') &&  get_field('contact_bg_image') ) {
								the_field('contact_bg_image');
							} else {
								bloginfo('template_url'); ?>/assets/img/contact_bg.webp<?php
					
						 }?>');"
        >
          <div class="container">
            <div class="contact__body">
              <h3 class="contact__title"><?php 
              if( function_exists('get_field')){
                    the_field('contact_title'); 
                  } else {
                    echo 'WE’D LOVE TO HEAR ABOUT YOUR PROJECt';
                }
              ?></h3>
				        <?php
                if( function_exists('wpcf7')){
                  echo do_shortcode('[contact-form-7 id="27" title="Contact form"]');
                } else {
                 echo 'Please install plugin Contact Form 7';
                } ?>
            </div>
          </div>
        </section>
        <!-- contact END -->
      </main>

<?php get_footer(); ?>
