	<footer class="footer">
        <div class="container">
          <div class="footer__body">
            <div class="logo">
              <?php 
              
              if( get_custom_logo() ) {
                the_custom_logo();
              } else {
                ?><a href="/"> <img src="<?php bloginfo('template_url'); ?>/assets/img/icon/logo.svg" alt=""> </a><?php
              }
              
              ?>
            </div>
            <div class="footer__copyright">
              © 2022 <a href="#"><?php bloginfo('name'); ?></a>. All Right Reserved.
            </div>

            <div class="footer__privacy">
              <a href="/?page_id=57">Terms of Service</a> <a href="/?page_id=59">Privacy Policy</a>
            </div>
          </div>
        </div>
	</footer>
    </div>

    <div class="go-top">
      <a href="#top"> </a>
    </div>

   
  <?php wp_footer(); ?>
    
</body>
</html>
